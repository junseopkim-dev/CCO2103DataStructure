public interface ISorter {
	int[] ascending(int[] a);
	int[] descending(int[] a);
}
