/*
 * Name:
 * Student ID #:
 */

/*
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public class Sorter implements ISorter {
	public Sorter() { ; }

	@Override
	public int[] ascending(int[] a) {
		/*
		 * Input:
		 *	- an integer array A
		 *
		 * Output: a sorted array A in *ascending* order.
		 */
		return null;
	}

	@Override
	public int[] descending(int[] a) {
		/*
		 * Input:
		 *	- an integer array A
		 *
		 * Output: a sorted array A in *descending* order.
		 */
		return null;
	}
}
