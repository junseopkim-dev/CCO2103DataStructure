public interface IYonseiSubstringSearch {
    public int countPattern(YonseiString p);
}
