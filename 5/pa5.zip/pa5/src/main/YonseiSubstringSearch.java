/*
 * Name:
 * Student ID #:
 */

/*
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public final class YonseiSubstringSearch implements IYonseiSubstringSearch {
    /*
     * you may declare variables here
     */

    YonseiSubstringSearch(YonseiString t) {
        /*
         * implement your constructor here.
         */
    }

    @Override
    public int countPattern(YonseiString p) {
        /*
         * Function input:
         *  + p: pattern to match in the target string.
         *
         * Does:
         * returns the number of occurrences of the pattern as a substring of the text given from the constructor.
         */
        return -1;
    }
}
