public class HashParameter {
    int a1, a2, b1, b2, N;

    HashParameter(int a1, int a2, int b1, int b2, int N){
        this.a1 = a1;
        this.a2 = a2;
        this.b1 = b1;
        this.b2 = b2;
        this.N = N;
    }
}
