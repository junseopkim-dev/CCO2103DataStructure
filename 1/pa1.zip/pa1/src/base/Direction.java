public enum Direction {
	TO_NEXT,TO_PREVIOUS
}
