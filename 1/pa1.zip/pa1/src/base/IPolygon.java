public interface IPolygon {
	public boolean pointInPolygon(Point p);
}
