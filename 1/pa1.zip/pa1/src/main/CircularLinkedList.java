/*
 * Name:
 * Student ID #:
 */

/*
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public class CircularLinkedList<T> implements ICLL<T> {
	class Node {
		Node next;
		Node previous;
		// you can further implement your node class here.
	}

	private Node head;
	// you may declare additional variables here.

	public CircularLinkedList() {
		// implement your constructor here.
	}

	@Override
	public int size() {
		/*
		 * Input:
		 *	- none
		 *
		 * Output:
		 *  - the number of elements in the linked list.
		 */
		return -1;
	}

	@Override
	public boolean isEmpty() {
		/*
		 * Input:
		 *	- none
		 *
		 * Output:
		 *  - whether or not the list is empty.
		 */
		return false;
	}

	@Override
	public T getHead() {
		/*
		 * Input:
		 *	- none
		 *
		 * Output: 
		 *  - the element stored in the node pointed by the head.
		 */
		return null;
	}

	@Override
	public void rotate(Direction direction) {
		/*
		 * Input:
		 *	- the rotation orientation
		 *
		 * Output: 
		 *  - none
		 * 
		 * Does:
		 *  - rotates the linked list so that the head points to the Node in that direction.
		 */
		return;
	}

	@Override
	public void insert(T element) {
		/*
		 * Input:
		 *	- element to be inserted to the list
		 *
		 * Output: 
		 *  - none
		 * 
		 * Does:
		 *  - inserts the given element before the Node pointed by the head.
		 */
		return;
	}

	@Override
	public T delete() {
		/*
		 * Input:
		 *	- none
		 *
		 * Output:
		 *  - the element pointed to by the head at the start of the method call.
		 * 
		 * Does:
		 *  - deletes the element pointed to by the head and returns it.
		 *  - if the list is empty, return null.
		 * 
		 * Note:
		 *  - if nonempty after deletion,
		 *    the new head should be the next node of the original head.
		 */
		return null;
	}

	@Override
	public boolean find(T target) {
		/*
		 * Input:
		 *	- target element to find in the list.
		 *
		 * Output:
		 *  - whether or not the search succeeded.
		 * 
		 * Does:
		 *  - moves the head to the first instance of target in the list if the search succeeded.
		 *  - does not move the head if the search failed.
		 */
		return false;
	}
}
