public interface IPostfixCalculator {
    public int evaluate(String exp);
}
