public interface IMatchMaker {
    public Player[] newPlayer(Player player);
}
